package com.example.petrescuecapstone.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.petrescuecapstone.R

class AddressActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_address)
    }
}