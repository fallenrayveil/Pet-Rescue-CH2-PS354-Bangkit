package com.example.petrescuecapstone.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.viewpager.widget.ViewPager
import com.example.petrescuecapstone.R
import com.example.petrescuecapstone.adapter.PetSwipeAdapter
import com.example.petrescuecapstone.databinding.FragmentTailBinding

class TailFragment : Fragment() {

    companion object{
        var viewPager: ViewPager? = null
    }

    lateinit var root : View
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        root =  inflater.inflate(R.layout.fragment_tail, container, false)

        viewPager = root.findViewById(R.id.viewpet)

        val fragmentAdapter = PetSwipeAdapter(requireActivity().supportFragmentManager)

        // Inflate the layout for this fragment


        viewPager!!.adapter = fragmentAdapter


        return  root

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setUpViewPager(viewPager!!)

    }

    private fun setUpViewPager(viewPager: ViewPager) {
        val adapter = PetSwipeAdapter(childFragmentManager)
        adapter.addFragment(LostFragment())
        adapter.addFragment(FoundFragment())
        viewPager.adapter = adapter
    }


}