package com.example.petrescuecapstone.ui

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.example.petrescuecapstone.R
import com.example.petrescuecapstone.data.UiState
import com.example.petrescuecapstone.databinding.ActivityAddPetBinding
import com.example.petrescuecapstone.viewmodel.PredictViewModel
import com.example.petrescuecapstone.viewmodel.ViewModelFactory
import com.squareup.picasso.Picasso
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.ByteArrayOutputStream
import java.io.File

class AddPetActivity : AppCompatActivity() {
    private val viewModel by viewModels<PredictViewModel> {
        ViewModelFactory.getInstance(this)
    }

    //foto
    var filePath: Uri? = null
    var data: ByteArray? = null
    private val REQUEST_PICK_IMAGE = 1
    private val REQUEST_CODE = 13
    var datafoto: ByteArray? = null

    companion object {
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS =
            mutableListOf(
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
            ).apply {
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                    add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            }.toTypedArray()
    }
    lateinit var binding: ActivityAddPetBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_add_pet)
        binding.lifecycleOwner = this
        val intent = intent
        val detail = intent.getStringExtra("detail")

        Log.d("surabaya", "onCreate: $detail")
        binding.btnGallery.setOnClickListener {
            pilihfile()
        }

        binding.btnCamera.setOnClickListener {
            permission()

        }
        binding.btnUpload.setOnClickListener {
            if (data != null) {
                val f: File = File(cacheDir, "image")
                f.createNewFile()

                val reqFile = RequestBody.create("image/*".toMediaTypeOrNull(), data!!)
                val body = MultipartBody.Part.createFormData("image", f.name, reqFile)

                viewModel.predict(body).observe(this) { result ->
                    when (result) {
                        is UiState.Loading -> {
                            showLoading(true)
                        }

                        is UiState.Success -> {
                            val intent = Intent(this, InfoPetStatus::class.java)
                            intent.putExtra(
                                "image",
                                result.data.predImg.toString()
                            )
                            intent.putExtra("id_pet", result.data.petId)
                            intent.putExtra("detail", detail)
                            startActivity(intent)
                        }

                        is UiState.Error -> {
                            showLoading(false)
                            showToast(result.error)
                        }

                    }
                }

            }
        }

    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar2.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    fun permission() {
        // Request camera permissions
        if (allPermissionsGranted()) {
            camera()
        } else {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS
            )
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(
            baseContext, it
        ) == PackageManager.PERMISSION_GRANTED
    }


    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults:
        IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {

            } else {
                Toast.makeText(
                    this,
                    "Permissions not granted by the user.",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    var cameraUri: Uri? = null
    var selectedImageUri: Uri? = null

    private fun camera() {
        var values = ContentValues()
        values.put(MediaStore.Images.Media.TITLE, "MyPicture")
        values.put(
            MediaStore.Images.Media.DESCRIPTION,
            "Photo taken on " + System.currentTimeMillis()
        )
        cameraUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)

//this is used to open camera and get image file
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
        startActivityForResult(cameraIntent, REQUEST_CODE)
    }


    private fun pilihfile() {
        //Intent to pick image
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, REQUEST_PICK_IMAGE)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_PICK_IMAGE) {
                filePath = data?.data
                Picasso.get().load(filePath).fit().centerCrop().into(binding.imageView)
                convert()
            } else if (requestCode == REQUEST_CODE) {
                Log.i("CameraCapture", cameraUri.toString())
                selectedImageUri = cameraUri
                Log.i("ImagePICK", selectedImageUri.toString())

                Picasso.get().load(selectedImageUri).fit().centerCrop().into(binding.imageView)
                convert()
            }


        }
    }

    fun convert() {
        val bmp = MediaStore.Images.Media.getBitmap(contentResolver, filePath)
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 80, baos)
        data = baos.toByteArray()

    }
}