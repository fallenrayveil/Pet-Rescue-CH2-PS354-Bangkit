package com.example.petrescuecapstone.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.petrescuecapstone.R

class KontakUserActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kontak_user)
    }
}